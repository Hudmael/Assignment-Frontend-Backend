<div class="intro">
    <div class="container">
      <div class="row">
        <div class="col">
          <div class="section_title text-center">
            <div>Welcome</div>
            <h1>To Royal Hotel </h1>
          </div>
        </div>
      </div>
     
      <div class="row gallery_row">
        <div class="col">

          <!-- Gallery -->
          <div class="gallery_slider_container">
            <div class="owl-carousel owl-theme gallery_slider">
              
              <!-- Slide -->
              <div class="gallery_slide">
                <img src="images/gallery_1.jpg" alt="">
                <div class="gallery_overlay">
                  <div class="text-center d-flex flex-column align-items-center justify-content-center">
                    <a href="#">
                      <!-- <span>+</span>
                      <span>See More</span> -->
                    </a>
                  </div>
                </div>
              </div>

              <!-- Slide -->
              <div class="gallery_slide">
                <img src="images/gallery_2.jpg" alt="">
                <div class="gallery_overlay">
                  <div class="text-center d-flex flex-column align-items-center justify-content-center">
                    <a href="#">
                      <!-- <span>+</span>
                      <span>See More</span> -->
                    </a>
                  </div>
                </div>
              </div>

              <!-- Slide -->
              <div class="gallery_slide">
                <img src="images/gallery_3.jpg" alt="">
                <div class="gallery_overlay">
                  <div class="text-center d-flex flex-column align-items-center justify-content-center">
                    <a href="#">
                      <!-- <span>+</span>
                      <span>See More</span> -->
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>

        </div>
      </div>
    </div>
  </div>

  <!-- Rooms -->

  <div class="rooms_right container_wrapper">
    <div class="container">
      <div class="row row-eq-height">

        <!-- Rooms Image -->
        <div class="col-xl-6 order-xl-1 order-2">
          <div class="rooms_slider_container">
            <div class="owl-carousel owl-theme rooms_slider">
              
              <!-- Slide -->
              <div class="slide">
                <div class="background_image" style="background-image:url(images/rooms1.jpg)"></div>
              </div>

              <!-- Slide -->
              <div class="slide">
                <div class="background_image" style="background-image:url(images/rooms1.jpg)"></div>
              </div>

              <!-- Slide -->
              <div class="slide">
                <div class="background_image" style="background-image:url(images/rooms1.jpg)"></div>
              </div>

            </div>
          </div>
        </div>

        <!-- Rooms Content -->
        <div class="col-xl-6 order-xl-2 order-1">
          <div class="rooms_right_content">
            <div class="section_title">
              <div>Rooms</div>
              <h1>Luxury Double Suite</h1>
            </div>
            <div class="rooms_text">
              <p>Luxury Double Suite has a comfortable two king size, a sitting area, separate desk and bathroom with walk-in rain dance shower or a bath and shower and modern art and neutral colors.

The rooms come with full amenities; Flat Screen TV, Wi-Fi, THE SPA COLLECTION amenities, air-conditioning, hairdryer, safe, minibar and complimentary coffee & tea facilities.</p>
            </div>
            <div class="rooms_list">
              <ul>
                <li class="d-flex flex-row align-items-center justify-content-start">
                  <img src="images/check.png" alt="">
                  <span>Free Wifi</span>
                </li>
                <li class="d-flex flex-row align-items-center justify-content-start">
                  <img src="images/check.png" alt="">
                  <span>Occupancy: 2 Persons</span>
                </li>
                <li class="d-flex flex-row align-items-center justify-content-start">
                  <img src="images/check.png" alt="">
                  <span>Free Gym Access</span>
                </li>
              </ul>
            </div>
            <div class="rooms_price">RM550/<span>Night</span></div>
           
          </div>
        </div>

      </div>
    </div>
  </div>

  <!-- Rooms -->

  <div class="rooms_left container_wrapper">
    <div class="container">
      <div class="row row-eq-height">
        
        <!-- Rooms Content -->
        <div class="col-xl-6">
          <div class="rooms_left_content">
            <div class="section_title">
              <div>Rooms</div>
              <h1>Luxury Single Room</h1>
            </div>
            <div class="rooms_text">
              <p>Luxury Single Room has a comfortable queen size or twin bed, a sitting area,  a bath and shower and modern art and neutral colors.

The rooms come with full amenities; Flat Screen TV, Wi-Fi,  air-conditioning, hairdryer, safe, minibar and complimentary coffee & tea facilities.</p>
            </div>
            <div class="rooms_list">
              <ul>
                <li class="d-flex flex-row align-items-center justify-content-start">
                  <img src="images/check.png" alt="">
                  <span>Free Wifi</span>
                </li>
                <li class="d-flex flex-row align-items-center justify-content-start">
                  <img src="images/check.png" alt="">
                  <span>Free Gym Access</span>
                </li>
                
              </ul>
            </div>
            <div class="rooms_price">RM250/<span>Night</span></div>
           
          </div>
        </div>

        <!-- Rooms Image -->
        <div class="col-xl-6">
          <div class="rooms_slider_container">
            <div class="owl-carousel owl-theme rooms_slider">
              
              <!-- Slide -->
              <div class="slide">
                <div class="background_image" style="background-image:url(images/rooms2.jpeg)"></div>
              </div>

              <!-- Slide -->
              <div class="slide">
                <div class="background_image" style="background-image:url(images/rooms2.jpeg)"></div>
              </div>

              <!-- Slide -->
              <div class="slide">
                <div class="background_image" style="background-image:url(images/rooms2.jpeg)"></div>
              </div>
              
            </div>
          </div>
        </div>

      </div>
    </div>
  </div>

  <!-- Discover -->

  <div class="discover">

    <!-- Discover Content -->
    <div class="discover_content">
      <div class="container">
        <div class="row">
          <div class="col-lg-5">
            <div class="section_title">
              <div>Hotel</div>
              <h1>Discover Royal Hotel</h1>
            </div>
          </div>
        </div>
        <div class="row discover_row">
          <div class="col-lg-5">
            
            <!-- <div class="button discover_button"><a href="#">discover</a></div> -->
          </div>
          <div class="col-lg-7">
            <div class="discover_text">
              <p> The Royal Hotel is a 5-star luxury homegrown hospitality label located in the heart of the Georgetown world heritage site. 
			It welcomes the urbane traveller to a magical contemporized colonial scene, with 162 rooms, 
			an all-day dining outlet, an arcade with a mix of retail outlets, event spaces and a rooftop infinity pool.
			The Royal Hotel brings local inspiration to life for intrepid world travellers seeking to experience local charm at its best. It is the perfect designer living space for the busy business executive and the contemporary world traveller of today.</p>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Discover Slider -->
    <div class="discover_slider_container">
      <div class="owl-carousel owl-theme discover_slider">
        
        <!-- Slide -->
        <div class="slide">
          <div class="background_image" style="background-image:url(images/discover1.jpg)"></div>
          <div class="discover_overlay d-flex flex-column align-items-center justify-content-center">
            <h1><a href="#">Weddings</a></h1>
          </div>
        </div>

        <!-- Slide -->
        <div class="slide">
          <div class="background_image" style="background-image:url(images/discover2.jpg)"></div>
          <div class="discover_overlay d-flex flex-column align-items-center justify-content-center">
            <h1><a href="#">Resort</a></h1>
          </div>
        </div>

        <!-- Slide -->
        <div class="slide">
          <div class="background_image" style="background-image:url(images/discover3.jpg)"></div>
          <div class="discover_overlay d-flex flex-column align-items-center justify-content-center">
            <h1><a href="#">Spa</a></h1>
          </div>
        </div>

      </div>
    </div>

  </div>

 
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
